function animatep(p)


