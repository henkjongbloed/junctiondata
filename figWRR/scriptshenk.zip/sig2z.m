function z = sig2z(sig, zb, eta)

z = zb + (eta - zb).*sig;

end